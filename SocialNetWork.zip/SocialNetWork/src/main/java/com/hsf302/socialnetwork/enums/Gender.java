package com.hsf302.socialnetwork.enums;

public enum Gender {
    F,M
}
