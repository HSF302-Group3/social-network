package com.hsf302.socialnetwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialNetWorkApplication {

    public static void main(String[] args) {
        SpringApplication.run(SocialNetWorkApplication.class, args);
    }

}
