package com.hsf302.socialnetwork.enums;

public enum Role {
    ADMIN,USER
}
