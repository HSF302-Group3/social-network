package com.hsf302.socialnetwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialNetWorkApplicationTests {

    @Test
    void contextLoads() {
    }

}
